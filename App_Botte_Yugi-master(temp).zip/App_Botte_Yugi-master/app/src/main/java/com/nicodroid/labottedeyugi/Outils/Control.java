package com.nicodroid.labottedeyugi.Outils;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.widget.Toast;

import com.nicodroid.labottedeyugi.MainActivity;

public class Control {
    public static void setToastError(Context context, String message)
    {
        MainActivity Context=(MainActivity)context;

        Context.TV_status.setText("Erreur QR_CODE");
        Context.TV_status.setTextColor(Color.BLACK);

        Context.TV_id.setText("");
        Context.TV_name.setText("");
        Context.TV_surname.setText("");
        Context.TV_pseudo.setText("");
        Context.TV_postal_code.setText("");
        Context.TV_birth.setText("");
        Context.TV_inscription.setText("");

        Context.BT_modif.setEnabled(false);
    }
}
