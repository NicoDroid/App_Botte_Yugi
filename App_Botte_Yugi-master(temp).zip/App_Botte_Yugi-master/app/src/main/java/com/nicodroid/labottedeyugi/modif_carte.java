package com.nicodroid.labottedeyugi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.nicodroid.labottedeyugi.AccesServer.AccesDistant;
import com.nicodroid.labottedeyugi.ClasseUses.Profil_Cartes;

import org.json.JSONArray;

public class modif_carte extends AppCompatActivity {

    private static AccesDistant accesDistant;

    private TextView TV_ID;

    private EditText ET_Pseudo;
    private EditText ET_Name;
    private EditText ET_Surname;
    private EditText ET_Locality;
    private EditText ET_DateBirth;
    private EditText ET_DateInscription;

    private RadioButton RB_Active;
    private RadioButton RB_Disactive;

    Intent intent;
    public Intent returnIntent=new Intent();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modif_carte);

        intent=getIntent();

        accesDistant=new AccesDistant(modif_carte.this);

        TV_ID=(TextView)findViewById(R.id.TV_ID);

        ET_Pseudo=(EditText)findViewById(R.id.ET_Pseudo);
        ET_Name=(EditText)findViewById(R.id.ET_Name);
        ET_Surname=(EditText)findViewById(R.id.ET_Surname);
        ET_Locality=(EditText)findViewById(R.id.ET_Locality);
        ET_DateBirth=(EditText)findViewById(R.id.ET_DateBirth);
        ET_DateInscription=(EditText)findViewById(R.id.ET_DateInscription);

        RB_Active=(RadioButton) findViewById(R.id.RB_Active);
        RB_Disactive=(RadioButton)findViewById(R.id.RB_Disactive);

        TV_ID.setText(intent.getStringExtra("ID"));
        if(intent.getStringExtra("Status").equals("Active"))
        {
            RB_Active.setChecked(true);
        }else
        {
            RB_Disactive.setChecked(true);
        }
        if(intent.getStringExtra("Pseudo").equals("null"))
        {
            ET_Pseudo.setText("Pseudo");
        }else
        {
            ET_Pseudo.setText(intent.getStringExtra("Pseudo"));
        }
        if(intent.getStringExtra("Name").equals("null"))
        {
            ET_Name.setText("Nom");
        }else
        {
            ET_Name.setText(intent.getStringExtra("Name"));
        }
        if(intent.getStringExtra("Surname").equals("null"))
        {
            ET_Surname.setText("Prenom");
        }else
        {
            ET_Surname.setText(intent.getStringExtra("Surname"));
        }
        if(intent.getStringExtra("Locality").equals("null"))
        {
            ET_Locality.setText("Localite");
        }else
        {
            ET_Locality.setText(intent.getStringExtra("Locality"));
        }
        if(intent.getStringExtra("DateBirth").equals("null"))
        {
            ET_DateBirth.setText("Date de naissance");
        }else
        {
            ET_DateBirth.setText(intent.getStringExtra("DateBirth"));
        }
        if(intent.getStringExtra("DateInscription").equals("null"))
        {
            ET_DateInscription.setText("Date d'inscription");
        }else
        {
            ET_DateInscription.setText(intent.getStringExtra("DateInscription"));
        }

        final Button BT_Valider=(Button)findViewById(R.id.BT_Valider);
        BT_Valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String active;
                if(RB_Active.isChecked())
                {
                    active="1";
                }else
                {
                    active="0";
                }

                Profil_Cartes profil=new Profil_Cartes(intent.getStringExtra("ID"),active,ET_Pseudo.getText().toString(),ET_Name.getText().toString(),ET_Surname.getText().toString(),ET_Locality.getText().toString(),ET_DateBirth.getText().toString(),ET_DateInscription.getText().toString());
                accesDistant.envoi(2,intent.getStringExtra("ID"),profil.convertToJSON());
                Log.d("Test",profil.convertToJSON().toString());
            }
        });
    }
}
