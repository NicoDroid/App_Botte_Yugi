package com.nicodroid.labottedeyugi.AccesServer;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.nicodroid.labottedeyugi.ClasseUses.Profil_Cartes;
import com.nicodroid.labottedeyugi.MainActivity;
import com.nicodroid.labottedeyugi.Outils.Control;
import com.nicodroid.labottedeyugi.modif_carte;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AccesDistant implements AsyncResponse {

    private int operation;
    protected Context context;

    public AccesDistant(Context context){
        this.context=context;
    }

    @Override
    public void processFinish(String output) {
        Log.d("server","*********"+output);

        String[] message=output.split("%"); //Découpage du message reçu avec % [0]: enreg,dernier,erreur [1]: reste

        if (message.length==1 && operation!=2)
        {
            Log.d("server","erreur");
            Control.setToastError(context,"QR_Code Invalide !!!");
        }else
        {
            if (operation==1)
            {
                try{
                    JSONObject info=new JSONObject(message[1]);
                    Profil_Cartes profil=new Profil_Cartes(info.getString("ID_Carte"),info.getString("Active"),info.getString("Pseudo"),info.getString("Nom"),info.getString("Prenom"),info.getString("Localite"),info.getString("Date_Naissance"),info.getString("Date_Inscription"));
                    profil.SetProfil_Cartes(context);
                }catch(JSONException e)
                {
                    Log.d("erreur","conversion JSON impossible*****"+e.toString());
                }
            }else if(operation==2)
            {
                Log.d("server","*********"+output);
                modif_carte contextSet=(modif_carte)context;
                contextSet.setResult(contextSet.RESULT_OK,contextSet.returnIntent);
                contextSet.finish();
            }
        }

    }

    public void envoi(int op, String ID, JSONArray DonneesJSON){
        this.operation=op;
        Acces_HTTP accesDonnees=new Acces_HTTP();

        accesDonnees.delegate = this;

        accesDonnees.addParam("ID",ID);
        accesDonnees.addParam("donnees",DonneesJSON.toString());

        if(op==1)
        {
            String SERVERADDR="http://109.89.152.107:80/get_carte.php";
            accesDonnees.execute(SERVERADDR);
        }else if(op==2)
        {
            String SERVERADDR="http://109.89.152.107:80/modif_carte.php";
            accesDonnees.execute(SERVERADDR);
        }
    }
}
