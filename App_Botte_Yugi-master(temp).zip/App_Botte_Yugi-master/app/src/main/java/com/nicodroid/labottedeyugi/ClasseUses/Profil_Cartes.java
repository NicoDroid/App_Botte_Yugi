package com.nicodroid.labottedeyugi.ClasseUses;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.util.Log;

import com.nicodroid.labottedeyugi.MainActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Profil_Cartes {
    private String ID_Carte;
    private String Active;
    private String Pseudo;
    private String Name;
    private String Surname;
    private String Locality;
    private String Date_Birthday;
    private String Date_Inscription;

    private MainActivity context;

    public Profil_Cartes(String ID_Carte,String Active, String Pseudo,String Name, String Surname, String Locality, String Date_Bithday, String Date_Inscription)
    {
        this.ID_Carte=ID_Carte;
        this.Active=Active;
        this.Pseudo=Pseudo;
        this.Name=Name;
        this.Surname=Surname;
        this.Locality=Locality;
        this.Date_Birthday=Date_Bithday;
        this.Date_Inscription=Date_Inscription;
    }

    public void SetProfil_Cartes(Context context)
    {
        this.context=(MainActivity)context;
        this.context.TV_id.setText(ID_Carte);
        this.context.TV_status.setText(Active.toString());

        if(Active.equals("1"))
        {
            this.context.TV_status.setText("Active");
            this.context.TV_status.setTextColor(Color.GREEN);
        }else
        {
            this.context.TV_status.setText("No-Active");
            this.context.TV_status.setTextColor(Color.RED);
        }

        this.context.TV_pseudo.setText(Pseudo);
        this.context.TV_name.setText(Name);
        this.context.TV_surname.setText(Surname);
        this.context.TV_postal_code.setText(Locality);
        this.context.TV_birth.setText(Date_Birthday);
        this.context.TV_inscription.setText(Date_Inscription);

        this.context.BT_modif.setEnabled(true);
    }

    public JSONArray convertToJSON()
    {
        List liste=new ArrayList();
        liste.add(ID_Carte);
        liste.add(Active);
        liste.add(Pseudo);
        liste.add(Name);
        liste.add(Surname);
        liste.add(Locality);
        liste.add(Date_Birthday);
        liste.add(Date_Inscription);
        return new JSONArray(liste);
    }
}
