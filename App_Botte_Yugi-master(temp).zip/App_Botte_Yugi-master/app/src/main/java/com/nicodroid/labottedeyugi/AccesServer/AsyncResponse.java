package com.nicodroid.labottedeyugi.AccesServer;

public interface AsyncResponse {
    void processFinish(String output);
}
