package com.nicodroid.labottedeyugi;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;

import com.nicodroid.labottedeyugi.AccesServer.AccesDistant;
import com.nicodroid.labottedeyugi.Outils.CheckNetworkStatus;

import org.json.JSONArray;

/*
    Operation 1: récupérer les infos de la carte
    Opération 2: modifier une carte
 */

public class MainActivity extends AppCompatActivity {

    public TextView TV_id;
    public TextView TV_pseudo;
    public TextView TV_name;
    public TextView TV_surname;
    public TextView TV_status;
    public TextView TV_postal_code;
    public TextView TV_birth;
    public TextView TV_inscription;

    public Button BT_modif;

    private String ID;

    private static AccesDistant accesDistant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TV_id=(TextView)findViewById(R.id.TV_id);
        TV_pseudo=(TextView)findViewById(R.id.TV_pseudo);
        TV_name=(TextView)findViewById(R.id.TV_name);
        TV_surname=(TextView)findViewById(R.id.TV_surname);
        TV_status=(TextView)findViewById(R.id.TV_status);
        TV_postal_code=(TextView)findViewById(R.id.TV_postal_code);
        TV_birth=(TextView)findViewById(R.id.TV_birth);
        TV_inscription=(TextView)findViewById(R.id.TV_inscription);

        accesDistant=new AccesDistant(MainActivity.this);

        final Button BT_scan=(Button)findViewById(R.id.BT_Scan);
        BT_modif=(Button)findViewById(R.id.BT_modif);
        BT_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent scan_activity=new Intent(MainActivity.this,com.nicodroid.labottedeyugi.Outils.qr_scanner.class);
                startActivityForResult(scan_activity,1000);
            }
        });

        BT_modif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent modif_carte_activity=new Intent(MainActivity.this,modif_carte.class);
                modif_carte_activity.putExtra("ID",TV_id.getText().toString());
                modif_carte_activity.putExtra("Status",TV_status.getText().toString());
                modif_carte_activity.putExtra("Pseudo",TV_pseudo.getText().toString());
                modif_carte_activity.putExtra("Name",TV_name.getText().toString());
                modif_carte_activity.putExtra("Surname",TV_surname.getText().toString());
                modif_carte_activity.putExtra("Locality",TV_postal_code.getText().toString());
                modif_carte_activity.putExtra("DateBirth",TV_birth.getText().toString());
                modif_carte_activity.putExtra("DateInscription",TV_inscription.getText().toString());
                startActivityForResult(modif_carte_activity,2000);
            }
        });

        //Vérification de la connexion au réseau
        if(CheckNetworkStatus.isNetworkAvailable(this)==true)
        {
            BT_scan.setEnabled(true);
            BT_modif.setEnabled(true);
        }else
        {
            Toast.makeText(this, "Pas de connection réseau, TURN ON WIFI/MOBILE AND RESTART APP", Toast.LENGTH_LONG).show();
            BT_scan.setEnabled(false);
            BT_modif.setEnabled(false);
        }
        BT_modif.setEnabled(false);
    }

    protected void onActivityResult(int requestCode,int resultCode, Intent data){
        if(resultCode==RESULT_OK && requestCode==1000)
        {
            ID=data.getStringExtra("id");
            accesDistant.envoi(1,ID,new JSONArray());
        }else if(resultCode==RESULT_OK && requestCode==2000)
        {
            accesDistant.envoi(1,ID,new JSONArray());
        }
    }
}
